package sn.touba.xadimousalih.eurekanaminganddiscoveryserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EurekaNamingAndDiscoveryServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
