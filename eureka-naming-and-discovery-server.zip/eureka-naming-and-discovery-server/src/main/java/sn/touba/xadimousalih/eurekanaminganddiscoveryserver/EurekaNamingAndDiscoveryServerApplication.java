package sn.touba.xadimousalih.eurekanaminganddiscoveryserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EurekaNamingAndDiscoveryServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(EurekaNamingAndDiscoveryServerApplication.class, args);
	}

}
