package sn.touba.xadimousalih.declarationtimbreservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DeclarationTimbreServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(DeclarationTimbreServiceApplication.class, args);
	}

}
