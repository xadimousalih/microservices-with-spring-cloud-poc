package sn.touba.xadimousalih.paiementtimbreservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PaiementTimbreServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
