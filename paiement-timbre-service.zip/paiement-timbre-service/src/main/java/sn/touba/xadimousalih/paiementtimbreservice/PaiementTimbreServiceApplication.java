package sn.touba.xadimousalih.paiementtimbreservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PaiementTimbreServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(PaiementTimbreServiceApplication.class, args);
	}

}
